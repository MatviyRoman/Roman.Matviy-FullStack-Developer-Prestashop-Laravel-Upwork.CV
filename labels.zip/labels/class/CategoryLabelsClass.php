<?php

class CategoryLabelsClass extends ObjectModel
{
	public $id_labels;
	public $id_category;
	public $name;
	public $color;
	public $active;

	public static $definition = [
		'table'   => 'labels',
		'primary' => 'id_labels',
		'fields'  => [
			'id_category'          => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt', 'required' => true, ],
			'name'                 => ['type' => self::TYPE_STRING, 'validate' => 'isAnything', 'required' => true],
			'color'                => ['type' => self::TYPE_STRING, 'validate' => 'isAnything', 'required' => true, ],
			'active'               => ['type' => self::TYPE_BOOL, 'validate' => 'isUnsignedInt', 'required' => true, ],
		],
	];
}
